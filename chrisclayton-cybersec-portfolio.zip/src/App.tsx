import { motion } from "motion/react";
import { Shield, Network, Award, Terminal, Mail, Github, Linkedin, ExternalLink, ChevronRight, Lock, Cpu, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";

const SectionHeading = ({ title, subtitle, icon: Icon }: { title: string; subtitle?: string; icon?: any }) => (
  <div className="mb-12 space-y-2">
    <div className="flex items-center gap-2 text-primary">
      {Icon && <Icon size={20} />}
      <span className="text-xs font-mono uppercase tracking-[0.2em]">{subtitle || "Section"}</span>
    </div>
    <h2 className="text-3xl md:text-4xl font-bold tracking-tight">{title}</h2>
    <div className="h-1 w-20 bg-primary/20 rounded-full" />
  </div>
);

export default function App() {
  return (
    <div className="min-h-screen bg-linear-to-br from-[oklch(0.96_0.02_240)] to-[oklch(0.96_0.02_140)] text-foreground selection:bg-primary/30">
      {/* Grid Background */}
      <div className="fixed inset-0 z-[-1] opacity-[0.03] pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)', backgroundSize: '40px 40px' }} />

      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-1.5 rounded-lg">
              <Shield className="text-primary-foreground" size={20} />
            </div>
            <span className="font-mono font-bold tracking-tighter text-xl">CYBER_CORE</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
            <a href="#about" className="hover:text-primary transition-colors">About</a>
            <a href="#certs" className="hover:text-primary transition-colors">Certifications</a>
            <a href="#skills" className="hover:text-primary transition-colors">Skills</a>
            <a href="#projects" className="hover:text-primary transition-colors">Projects</a>
          </div>
          <Button variant="outline" size="sm" className="font-mono">
            GET_IN_TOUCH
          </Button>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-12 space-y-32">
        {/* Hero Section */}
        <section id="about" className="relative pt-12 md:pt-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              <Badge variant="secondary" className="px-3 py-1 font-mono text-xs uppercase tracking-wider">
                Available for Security Audits
              </Badge>
              <h1 className="text-5xl md:text-7xl font-bold tracking-tighter leading-none">
                Securing the <span className="text-primary italic">Digital Frontier</span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-lg leading-relaxed">
                Networking & Cybersecurity Specialist. Certified CCNA professional dedicated to building resilient infrastructures and defending against evolving cyber threats.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="gap-2">
                  View Projects <ChevronRight size={18} />
                </Button>
                <Button size="lg" variant="outline" className="gap-2">
                  Download CV <Award size={18} />
                </Button>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative aspect-square md:aspect-auto md:h-[500px] bg-muted rounded-2xl overflow-hidden border group shadow-2xl"
            >
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1000&auto=format&fit=crop" 
                alt="Professional Portrait" 
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-primary/5 to-transparent opacity-60" />
              
              {/* Terminal Overlay */}
              <div className="absolute bottom-4 left-4 right-4 bg-black/80 backdrop-blur p-4 rounded-lg border border-white/10 font-mono text-[10px] text-green-500/80">
                <div className="flex gap-2 mb-1">
                  <div className="w-2 h-2 rounded-full bg-red-500/50" />
                  <div className="w-2 h-2 rounded-full bg-yellow-500/50" />
                  <div className="w-2 h-2 rounded-full bg-green-500/50" />
                </div>
                <div>$ nmap -sV 192.168.1.1</div>
                <div>Starting Nmap 7.92 ( https://nmap.org )</div>
                <div>Nmap scan report for gateway (192.168.1.1)</div>
                <div>PORT     STATE SERVICE VERSION</div>
                <div>80/tcp   open  http    Apache httpd 2.4.41</div>
                <div>443/tcp  open  ssl/http Apache httpd 2.4.41</div>
                <div className="animate-pulse">_</div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Certifications Section */}
        <section id="certs">
          <SectionHeading title="Professional Certifications" subtitle="Credentials" icon={Award} />
          <div className="grid md:grid-cols-2 gap-6">
            <motion.div whileHover={{ y: -5 }} transition={{ type: "spring", stiffness: 300 }}>
              <Card className="h-full border-primary/20 bg-primary/5">
                <CardHeader>
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-primary/10 rounded-xl">
                      <Network className="text-primary" size={32} />
                    </div>
                    <Badge variant="outline" className="border-primary/30 text-primary">Active</Badge>
                  </div>
                  <CardTitle className="text-2xl">Cisco Certified Network Associate (CCNA)</CardTitle>
                  <CardDescription className="text-base">Cisco Systems | ID: CSCO12345678</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">
                    Comprehensive knowledge of network fundamentals, IP connectivity, IP services, security fundamentals, and automation and programmability.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">Routing & Switching</Badge>
                    <Badge variant="secondary">IP Addressing</Badge>
                    <Badge variant="secondary">VLANs</Badge>
                    <Badge variant="secondary">OSPF</Badge>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div whileHover={{ y: -5 }} transition={{ type: "spring", stiffness: 300 }}>
              <Card className="h-full border-primary/20 bg-primary/5">
                <CardHeader>
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-primary/10 rounded-xl">
                      <Shield className="text-primary" size={32} />
                    </div>
                    <Badge variant="outline" className="border-primary/30 text-primary">Active</Badge>
                  </div>
                  <CardTitle className="text-2xl">Cybersecurity Professional</CardTitle>
                  <CardDescription className="text-base">CompTIA Security+ / CEH Equivalent</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">
                    Expertise in identifying security risks, implementing protective measures, and responding to security incidents across diverse network environments.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">Threat Analysis</Badge>
                    <Badge variant="secondary">Cryptography</Badge>
                    <Badge variant="secondary">Ethical Hacking</Badge>
                    <Badge variant="secondary">Incident Response</Badge>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills">
          <SectionHeading title="Technical Arsenal" subtitle="Capabilities" icon={Terminal} />
          <Tabs defaultValue="networking" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="networking">Networking</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="tools">Tools & OS</TabsTrigger>
            </TabsList>
            <TabsContent value="networking" className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { name: "TCP/IP Stack", level: "Expert" },
                { name: "BGP / OSPF / EIGRP", level: "Advanced" },
                { name: "SD-WAN", level: "Intermediate" },
                { name: "Wireless Networking", level: "Advanced" },
                { name: "Network Design", level: "Expert" },
                { name: "Cisco IOS/NX-OS", level: "Expert" },
                { name: "Load Balancing", level: "Advanced" },
                { name: "IPv6 Migration", level: "Intermediate" },
              ].map((skill) => (
                <div key={skill.name} className="p-4 rounded-lg border bg-card flex flex-col gap-1">
                  <span className="font-medium">{skill.name}</span>
                  <span className="text-xs text-muted-foreground uppercase tracking-tighter">{skill.level}</span>
                </div>
              ))}
            </TabsContent>
            <TabsContent value="security" className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { name: "Firewall (ASA/Palo Alto)", level: "Expert" },
                { name: "IDS/IPS Systems", level: "Advanced" },
                { name: "SIEM (Splunk/ELK)", level: "Advanced" },
                { name: "Penetration Testing", level: "Intermediate" },
                { name: "Vulnerability Scanning", level: "Expert" },
                { name: "Endpoint Security", level: "Advanced" },
                { name: "Identity Management", level: "Advanced" },
                { name: "Zero Trust Architecture", level: "Intermediate" },
              ].map((skill) => (
                <div key={skill.name} className="p-4 rounded-lg border bg-card flex flex-col gap-1">
                  <span className="font-medium">{skill.name}</span>
                  <span className="text-xs text-muted-foreground uppercase tracking-tighter">{skill.level}</span>
                </div>
              ))}
            </TabsContent>
            <TabsContent value="tools" className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { name: "Kali Linux", level: "Expert" },
                { name: "Wireshark", level: "Expert" },
                { name: "Metasploit", level: "Advanced" },
                { name: "Python (Automation)", level: "Advanced" },
                { name: "Docker / Kubernetes", level: "Intermediate" },
                { name: "Ansible", level: "Intermediate" },
                { name: "Windows Server", level: "Advanced" },
                { name: "Bash Scripting", level: "Advanced" },
              ].map((skill) => (
                <div key={skill.name} className="p-4 rounded-lg border bg-card flex flex-col gap-1">
                  <span className="font-medium">{skill.name}</span>
                  <span className="text-xs text-muted-foreground uppercase tracking-tighter">{skill.level}</span>
                </div>
              ))}
            </TabsContent>
          </Tabs>
        </section>

        {/* Projects Section */}
        <section id="projects">
          <SectionHeading title="Operational Experience" subtitle="Portfolio" icon={Globe} />
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Enterprise Network Hardening",
                desc: "Implemented a multi-layered security approach for a mid-sized enterprise, reducing attack surface by 40%.",
                tags: ["ASA", "VLAN Segmentation", "802.1X"],
                icon: Lock
              },
              {
                title: "Automated Threat Detection",
                desc: "Developed custom Python scripts to parse SIEM logs and automatically block suspicious IPs at the edge.",
                tags: ["Python", "Splunk", "API Integration"],
                icon: Cpu
              },
              {
                title: "Global SD-WAN Deployment",
                desc: "Architected and deployed a global SD-WAN solution connecting 15 branch offices with redundant links.",
                tags: ["SD-WAN", "BGP", "Cloud Connectivity"],
                icon: Globe
              }
            ].map((project, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="group overflow-hidden border-muted hover:border-primary/50 transition-colors h-full flex flex-col">
                  <div className="h-48 bg-muted flex items-center justify-center relative overflow-hidden">
                    <project.icon size={64} className="text-muted-foreground/20 group-hover:text-primary/20 transition-colors" />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                  </div>
                  <CardHeader>
                    <CardTitle className="group-hover:text-primary transition-colors">{project.title}</CardTitle>
                    <CardDescription>{project.desc}</CardDescription>
                  </CardHeader>
                  <CardContent className="mt-auto">
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.tags.map(tag => (
                        <Badge key={tag} variant="outline" className="text-[10px] uppercase tracking-tighter">{tag}</Badge>
                      ))}
                    </div>
                    <Button variant="ghost" size="sm" className="w-full gap-2 group/btn">
                      Case Study <ExternalLink size={14} className="group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Contact Section */}
        <section className="pb-24">
          <div className="bg-primary rounded-3xl p-12 text-primary-foreground relative overflow-hidden">
            <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl" />
            <div className="relative z-10 grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h2 className="text-4xl font-bold tracking-tight">Ready to secure your infrastructure?</h2>
                <p className="text-primary-foreground/80 text-lg">
                  I'm currently open to new opportunities and freelance security audits. Let's discuss how I can help protect your digital assets.
                </p>
                <div className="flex gap-4">
                  <Button size="lg" variant="secondary" className="gap-2">
                    <Mail size={18} /> Contact Me
                  </Button>
                  <div className="flex gap-2">
                    <Button size="icon" variant="outline" className="bg-white/10 border-white/20 hover:bg-white/20">
                      <Github size={20} />
                    </Button>
                    <Button size="icon" variant="outline" className="bg-white/10 border-white/20 hover:bg-white/20">
                      <Linkedin size={20} />
                    </Button>
                  </div>
                </div>
              </div>
              <div className="hidden md:block font-mono text-sm bg-black/20 p-6 rounded-2xl backdrop-blur border border-white/10">
                <div className="text-white/40 mb-4">// Connection established</div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>STATUS:</span>
                    <span className="text-green-400">ONLINE</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ENCRYPTION:</span>
                    <span className="text-green-400">AES-256</span>
                  </div>
                  <div className="flex justify-between">
                    <span>LOCATION:</span>
                    <span>REMOTE / GLOBAL</span>
                  </div>
                  <Separator className="bg-white/10 my-4" />
                  <div className="flex justify-between">
                    <span>LAST_SCAN:</span>
                    <span>09-APR-2026</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-12">
        <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <Shield className="text-primary" size={20} />
            <span className="font-mono font-bold tracking-tighter">CYBER_CORE</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2026 CyberSec Portfolio. All rights reserved. Built with precision.
          </p>
          <div className="flex gap-6 text-xs font-mono uppercase tracking-widest text-muted-foreground">
            <a href="#" className="hover:text-primary">Privacy</a>
            <a href="#" className="hover:text-primary">Terms</a>
            <a href="#" className="hover:text-primary">PGP_KEY</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
